
<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';

$user = require_login();

// Only lecturers can access this dashboard.
if ($user['role'] !== 'lecturer') {
    http_response_code(403);
    exit('Access denied. Lecturer account required.');
}

$pdo = db();
$userId = (int)$user['id'];

// Get lecturer profile.
$stmt = $pdo->prepare("
    SELECT id, title, department, designation, is_active
    FROM lecturer_profiles
    WHERE user_id = ?
    LIMIT 1
");
$stmt->execute([$userId]);
$lecturer = $stmt->fetch();

if (!$lecturer || (int)$lecturer['is_active'] !== 1) {
    http_response_code(403);
    exit('Your lecturer profile is not active. Contact an administrator.');
}

// Get assigned modules and academic groups.
$stmt = $pdo->prepare("
    SELECT
        m.module_code,
        m.module_name,
        d.name AS degree_name,
        b.batch_code,
        c.study_year,
        c.semester
    FROM lecturer_module_assignments lma
    INNER JOIN academic_curriculum c
        ON c.id = lma.curriculum_id
    INNER JOIN academic_modules m
        ON m.id = c.module_id
    INNER JOIN academic_degrees d
        ON d.id = c.degree_id
    INNER JOIN academic_batches b
        ON b.id = c.batch_id
    WHERE lma.lecturer_id = ?
      AND lma.is_active = 1
      AND c.is_active = 1
      AND m.is_active = 1
    ORDER BY c.study_year, c.semester, m.module_name
");
$stmt->execute([(int)$lecturer['id']]);
$modules = $stmt->fetchAll();

$fullName = (string)$user['full_name'];
$theme = (string)($user['theme'] ?? 'light');

if (!in_array($theme, ['light', 'dark', 'system'], true)) {
    $theme = 'light';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lecturer Dashboard | U Learn</title>

    <style>
        :root {
            --bg: #f7f8fc;
            --card: #ffffff;
            --text: #1b1d2c;
            --muted: #777b90;
            --border: #e7e8ef;
            --accent: #6856e8;
            --soft: #f0edff;
        }

        [data-theme="dark"] {
            --bg: #10121c;
            --card: #1b1e2b;
            --text: #f5f5fa;
            --muted: #a2a6b8;
            --border: #303344;
            --accent: #b1a4ff;
            --soft: #2c2745;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Inter, -apple-system, BlinkMacSystemFont,
                         "Segoe UI", sans-serif;
            background: var(--bg);
            color: var(--text);
        }

        .layout {
            display: grid;
            grid-template-columns: 245px 1fr;
            min-height: 100vh;
        }

        .sidebar {
            background: var(--card);
            border-right: 1px solid var(--border);
            padding: 30px 20px;
        }

        .brand {
            font-size: 27px;
            font-weight: 800;
            letter-spacing: -1.5px;
            margin-bottom: 50px;
        }

        .brand span {
            color: var(--accent);
        }

        .nav-label {
            color: var(--muted);
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 1.5px;
            margin-bottom: 15px;
        }

        .nav a {
            display: block;
            padding: 13px 15px;
            margin-bottom: 7px;
            border-radius: 12px;
            text-decoration: none;
            color: var(--text);
            font-size: 14px;
        }

        .nav a:hover,
        .nav a.active {
            background: var(--soft);
            color: var(--accent);
        }

        .main {
            padding: 35px clamp(20px, 5vw, 75px);
            min-width: 0;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            margin-bottom: 65px;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .theme-button {
            width: 42px;
            height: 42px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: var(--card);
            color: var(--text);
            cursor: pointer;
            font-size: 20px;
        }

        .avatar {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: var(--soft);
            color: var(--accent);
            display: grid;
            place-items: center;
            font-weight: 800;
        }

        h1 {
            font-size: clamp(34px, 4vw, 54px);
            letter-spacing: -2px;
            margin: 12px 0;
        }

        h1 span {
            color: var(--accent);
        }

        .eyebrow {
            color: var(--muted);
            font-size: 11px;
            letter-spacing: 1.6px;
            font-weight: 750;
        }

        .subtitle {
            color: var(--muted);
            max-width: 600px;
            line-height: 1.7;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 17px;
            margin: 40px 0;
        }

        .card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 19px;
            padding: 26px;
        }

        .stat-number {
            font-size: 35px;
            font-weight: 800;
            margin: 8px 0;
        }

        .stat-label {
            color: var(--muted);
            font-size: 13px;
        }

        .section-title {
            font-size: 23px;
            letter-spacing: -.6px;
            margin: 45px 0 20px;
        }

        .module-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 17px;
        }

        .module-code {
            color: var(--accent);
            font-size: 12px;
            font-weight: 750;
        }

        .module-name {
            font-size: 19px;
            font-weight: 700;
            margin: 13px 0;
        }

        .module-meta {
            color: var(--muted);
            font-size: 13px;
            line-height: 1.8;
        }

        .empty {
            background: var(--card);
            border: 1px dashed var(--border);
            border-radius: 18px;
            padding: 35px;
            color: var(--muted);
        }

        .logout {
            border: none;
            background: transparent;
            color: var(--muted);
            cursor: pointer;
            font-size: 13px;
        }

        @media (max-width: 850px) {
            .layout {
                grid-template-columns: 1fr;
            }

            .sidebar {
                border-right: none;
                border-bottom: 1px solid var(--border);
            }

            .brand {
                margin-bottom: 20px;
            }

            .main {
                padding: 25px 20px;
            }

            .stats,
            .module-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <script>
        const savedTheme = <?= json_encode($theme) ?>;

        function preferredTheme() {
            if (savedTheme === 'dark' || savedTheme === 'light') {
                return savedTheme;
            }

            return window.matchMedia(
                '(prefers-color-scheme: dark)'
            ).matches ? 'dark' : 'light';
        }

        let currentTheme = localStorage.getItem('ulearn-theme');

        if (currentTheme !== 'dark' && currentTheme !== 'light') {
            currentTheme = preferredTheme();
        }

        document.documentElement.dataset.theme = currentTheme;

        function toggleTheme() {
            currentTheme = document.documentElement.dataset.theme
                === 'dark' ? 'light' : 'dark';

            document.documentElement.dataset.theme = currentTheme;
            localStorage.setItem('ulearn-theme', currentTheme);
            updateThemeButton();
        }

        function updateThemeButton() {
            const button = document.getElementById('themeButton');

            if (button) {
                button.textContent =
                    currentTheme === 'dark' ? '☀' : '☾';

                button.setAttribute(
                    'aria-label',
                    currentTheme === 'dark'
                        ? 'Switch to light mode'
                        : 'Switch to dark mode'
                );
            }
        }

        document.addEventListener('DOMContentLoaded', updateThemeButton);
    </script>
</head>

<body>

<div class="layout">

    <aside class="sidebar">

        <div class="brand">
            u learn<span>.</span>
        </div>

        <div class="nav-label">LECTURER WORKSPACE</div>

        <nav class="nav">
            <a class="active" href="#overview">◫ Overview</a>
            <a href="#modules">▤ My Modules</a>
            <a href="#consultations">◷ Consultations</a>
            <a href="#notifications">♧ Notifications</a>
        </nav>

    </aside>

    <main class="main" id="overview">

        <header class="topbar">

            <div class="eyebrow">
                U LEARN / LECTURER PORTAL
            </div>

            <div class="topbar-right">

                <button
                    id="themeButton"
                    class="theme-button"
                    type="button"
                    onclick="toggleTheme()"
                    aria-label="Toggle appearance"
                    title="Change theme"
                >☾</button>

                <div class="avatar">
                    <?= e(strtoupper(substr($fullName, 0, 1))) ?>
                </div>

                <form
                    method="post"
                    action="<?= e(url('auth/logout.php')) ?>"
                >
                    <input
                        type="hidden"
                        name="csrf"
                        value="<?= e(csrf()) ?>"
                    >

                    <button class="logout" type="submit">
                        Log out
                    </button>
                </form>

            </div>
        </header>

        <div class="eyebrow">YOUR TEACHING WORKSPACE</div>

        <h1>
            Welcome, <?= e($lecturer['title']) ?>
            <?= e($fullName) ?><span>.</span>
        </h1>

        <p class="subtitle">
            Manage your assigned modules, connect with students,
            and respond to consultation requests from one place.
        </p>

        <section class="stats">

            <div class="card">
                <div class="eyebrow">ASSIGNED MODULES</div>
                <div class="stat-number">
                    <?= count($modules) ?>
                </div>
                <div class="stat-label">
                    Active teaching assignments
                </div>
            </div>

            <div class="card">
                <div class="eyebrow">CONSULTATION REQUESTS</div>
                <div class="stat-number">—</div>
                <div class="stat-label">
                    Available when booking is enabled
                </div>
            </div>

            <div class="card">
                <div class="eyebrow">NOTIFICATIONS</div>
                <div class="stat-number">—</div>
                <div class="stat-label">
                    Available in the next stage
                </div>
            </div>

        </section>

        <section id="modules">

            <h2 class="section-title">My Assigned Modules</h2>

            <?php if (!$modules): ?>

                <div class="empty">
                    No modules assigned yet.
                    An administrator will assign your
                    modules and academic batches.
                </div>

            <?php else: ?>

                <div class="module-grid">

                    <?php foreach ($modules as $module): ?>

                        <article class="card">

                            <div class="module-code">
                                <?= e($module['module_code']) ?>
                            </div>

                            <div class="module-name">
                                <?= e($module['module_name']) ?>
                            </div>

                            <div class="module-meta">
                                <?= e($module['degree_name']) ?><br>
                                Batch <?= e($module['batch_code']) ?><br>
                                Year <?= (int)$module['study_year'] ?>
                                · Semester <?= (int)$module['semester'] ?>
                            </div>

                        </article>

                    <?php endforeach; ?>

                </div>

            <?php endif; ?>

        </section>

        <section id="consultations">
            <h2 class="section-title">Consultation Requests</h2>

            <div class="empty">
                Students will be able to request consultation
                sessions for modules you teach.

                <br><br>

                Upcoming functionality:
                accept, decline, or suggest another time.
            </div>
        </section>

        <section id="notifications">
            <h2 class="section-title">Notifications</h2>

            <div class="empty">
                Your consultation notifications will
                appear here once the booking system
                is connected.
            </div>
        </section>

    </main>

</div>

</body>
</html>
