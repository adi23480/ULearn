<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';

$user = require_login();
if ((string)$user['role'] !== 'lecturer') {
    http_response_code(403);
    exit('Access denied. Lecturer account required.');
}

$pdo = db();
$userId = (int)$user['id'];
$notice = '';
$error = '';

function profileLoadUser(PDO $pdo, int $userId): array
{
    $stmt = $pdo->prepare('SELECT id, full_name, email, username, password_hash, theme FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$userId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        http_response_code(403);
        exit('Account unavailable.');
    }
    return $row;
}

$lecturerStmt = $pdo->prepare('SELECT title, department, designation, is_active FROM lecturer_profiles WHERE user_id = ? LIMIT 1');
$lecturerStmt->execute([$userId]);
$lecturer = $lecturerStmt->fetch(PDO::FETCH_ASSOC);
if (!$lecturer || (int)$lecturer['is_active'] !== 1) {
    http_response_code(403);
    exit('Your lecturer profile is not active. Contact an administrator.');
}

$profile = profileLoadUser($pdo, $userId);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = (string)($_POST['action'] ?? '');

    try {
        if ($action === 'update_profile') {
            $name = trim((string)($_POST['full_name'] ?? ''));
            if (mb_strlen($name) < 2 || mb_strlen($name) > 120) {
                throw new RuntimeException('Enter your full name (2–120 characters).');
            }
            $username=trim((string)($_POST['username'] ?? $profile['username'] ?? ''));
            if (!preg_match('/^[a-zA-Z][a-zA-Z0-9_.]{2,39}$/',$username)) throw new RuntimeException('Username must be 3–40 characters and start with a letter.');
            $unique=$pdo->prepare('SELECT id FROM users WHERE username=? AND id<>? LIMIT 1');$unique->execute([$username,$userId]);
            if ($unique->fetch()) throw new RuntimeException('Username already taken.');
            $stmt = $pdo->prepare('UPDATE users SET full_name = ?, username = ? WHERE id = ?');
            $stmt->execute([$name,$username,$userId]);
            $notice = 'Your profile has been updated.';
        } elseif ($action === 'change_password') {
            $current = (string)($_POST['current_password'] ?? '');
            $new = (string)($_POST['new_password'] ?? '');
            $confirm = (string)($_POST['confirm_password'] ?? '');
            if (!password_verify($current, (string)$profile['password_hash'])) {
                throw new RuntimeException('Your current password is incorrect.');
            }
            if (
                strlen($new) < 8 ||
                !preg_match('/[A-Z]/', $new) ||
                !preg_match('/[0-9]/', $new) ||
                !preg_match('/[^a-zA-Z0-9]/', $new)
            ) {
                throw new RuntimeException('Password needs at least 8 characters, an uppercase letter, a number and a symbol.');
            }
            if ($new !== $confirm) {
                throw new RuntimeException('The new passwords do not match.');
            }
            if (password_verify($new, (string)$profile['password_hash'])) {
                throw new RuntimeException('Choose a password different from your current password.');
            }
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
            $stmt->execute([$hash, $userId]);
            session_regenerate_id(true);
            $notice = 'Password changed successfully.';
        } elseif ($action === 'update_theme') {
            $theme = (string)($_POST['theme'] ?? 'system');
            if (!in_array($theme, ['light', 'dark', 'system'], true)) {
                throw new RuntimeException('Please select a valid appearance preference.');
            }
            $stmt = $pdo->prepare('UPDATE users SET theme = ? WHERE id = ?');
            $stmt->execute([$theme, $userId]);
            $notice = 'Appearance preference saved.';
        } else {
            throw new RuntimeException('Unknown action.');
        }
        $lecturerStmt = $pdo->prepare('SELECT title, department, designation, is_active FROM lecturer_profiles WHERE user_id = ? LIMIT 1');
$lecturerStmt->execute([$userId]);
$lecturer = $lecturerStmt->fetch(PDO::FETCH_ASSOC);
if (!$lecturer || (int)$lecturer['is_active'] !== 1) {
    http_response_code(403);
    exit('Your lecturer profile is not active. Contact an administrator.');
}

$profile = profileLoadUser($pdo, $userId);
    } catch (RuntimeException $ex) {
        $error = $ex->getMessage();
    }
}

$theme = (string)($profile['theme'] ?? 'system');
if (!in_array($theme, ['light', 'dark', 'system'], true)) {
    $theme = 'system';
}
$initial = strtoupper(substr(trim((string)$profile['full_name']), 0, 1));
?>
<!doctype html>
<html lang="en" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Lecturer Profile & Settings | U Learn</title>
<script>
(function () {
  var saved = <?= json_encode($theme, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  var local = localStorage.getItem('ulearn-theme');
  var pref = local === 'light' || local === 'dark' ? local : saved;
  var dark = pref === 'dark' || (pref === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
})();
</script>
<style>
:root{--bg:#f7f8fc;--card:#fff;--text:#1b1d2c;--muted:#777b90;--border:#e7e8ef;--accent:#6856e8;--soft:#f0edff;--input:#fff}
[data-theme="dark"]{--bg:#10121c;--card:#1b1e2b;--text:#f5f5fa;--muted:#a2a6b8;--border:#303344;--accent:#b1a4ff;--soft:#2c2745;--input:#171a26}
*{box-sizing:border-box}body{margin:0;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:var(--bg);color:var(--text)}a{color:inherit;text-decoration:none}.layout{min-height:100vh;display:grid;grid-template-columns:245px minmax(0,1fr)}.sidebar{background:var(--card);border-right:1px solid var(--border);padding:32px 20px}.brand{display:block;font-size:28px;font-weight:850;letter-spacing:-1.4px;margin-bottom:40px}.brand span,.intro h1 span{color:var(--accent)}.nav-label,.eyebrow{font-size:11px;font-weight:800;letter-spacing:1.5px;color:var(--muted);text-transform:uppercase}.nav{display:grid;gap:7px;margin-top:16px}.nav a{padding:13px 15px;border-radius:12px;font-weight:650;color:var(--muted)}.nav a:hover,.nav a.active{background:var(--soft);color:var(--accent)}.main{max-width:1120px;width:100%;margin:auto;padding:35px 42px 80px}.topbar{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:50px}.top-actions{display:flex;align-items:center;gap:12px}.pill{padding:9px 13px;border:1px solid var(--border);border-radius:99px;font-size:12px;color:var(--muted)}.theme-btn{height:42px;width:42px;border:1px solid var(--border);border-radius:12px;background:var(--card);color:var(--text);cursor:pointer;font-size:19px}.logout{font-weight:700;font-size:13px;color:var(--accent)}.intro{margin-bottom:28px}.intro h1{font-size:clamp(32px,4vw,48px);letter-spacing:-1.8px;margin:12px 0}.intro p,.hint{color:var(--muted);line-height:1.65}.profile-head{display:flex;align-items:center;gap:16px;margin-bottom:24px}.avatar{height:64px;width:64px;display:grid;place-items:center;border-radius:19px;background:var(--soft);color:var(--accent);font-weight:800;font-size:28px}.profile-head strong{display:block;font-size:18px}.profile-head small{display:block;color:var(--muted);margin-top:5px}.cards{display:grid;grid-template-columns:1fr 1fr;gap:20px}.card{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:26px}.card h2{margin:0 0 8px;font-size:21px}.card p{margin:0 0 22px}.card.wide{grid-column:1/-1}.field{margin-bottom:18px}.field label{display:block;font-size:13px;font-weight:700;margin-bottom:9px}.field input,.field select{width:100%;border:1px solid var(--border);border-radius:11px;padding:13px 14px;background:var(--input);color:var(--text);font:inherit}.field input:focus,.field select:focus{outline:2px solid var(--accent);outline-offset:1px}.field input[readonly]{opacity:.75;cursor:not-allowed}.btn{border:0;background:var(--accent);color:#fff;font:inherit;font-weight:750;padding:13px 19px;border-radius:11px;cursor:pointer}.btn:hover{filter:brightness(1.08)}.message{padding:14px 18px;border-radius:12px;margin-bottom:22px;border:1px solid var(--border)}.message.success{background:var(--soft);color:var(--accent)}.message.error{background:#fff0f0;color:#a32e36;border-color:#f4c5c5}[data-theme="dark"] .message.error{background:#3d242b;color:#ffb7bd;border-color:#75424d}.subtle{font-size:12px;color:var(--muted);margin-top:10px}@media(max-width:850px){.layout{display:block}.sidebar{border-right:0;border-bottom:1px solid var(--border);padding:18px}.brand{margin-bottom:14px}.nav{display:flex;overflow:auto;margin-top:10px}.nav a{white-space:nowrap}.main{padding:25px 18px 50px}.topbar{margin-bottom:30px}.cards{grid-template-columns:1fr}.card.wide{grid-column:auto}.card{padding:22px}.pill{display:none}}
</style>
</head>
<body>
<div class="layout">
<aside class="sidebar">
<a class="brand" href="<?= e(url('lecturer/index.php')) ?>">u learn<span>.</span></a>
<div class="nav-label">Lecturer workspace</div>
<nav class="nav" aria-label="Lecturer navigation">
<a href="<?= e(url('lecturer/index.php')) ?>">◫ &nbsp; Overview</a>
<a href="<?= e(url('lecturer/index.php#modules')) ?>">▤ &nbsp; My Modules</a>
<a href="<?= e(url('lecturer/materials.php')) ?>">▣ &nbsp; Study Materials</a>
<a href="<?= e(url('lecturer/quizzes.php')) ?>">☷ &nbsp; Quiz Management</a>
<a href="<?= e(url('lecturer/performance.php')) ?>">▥ &nbsp; Student Performance</a>
<a href="<?= e(url('lecturer/question-analytics.php')) ?>">◈ &nbsp; Question Analytics</a>
<a href="<?= e(url('lecturer/consultations.php')) ?>">◷ &nbsp; Consultations</a>
<a href="<?= e(url('dashboard/notifications.php')) ?>">♧ &nbsp; Notifications</a>
<a class="active" href="<?= e(url('lecturer/profile.php')) ?>" aria-current="page">⚙ &nbsp; My Profile & Settings</a>
</nav>
</aside>
<main class="main">
<header class="topbar"><div class="eyebrow">U LEARN / LECTURER PORTAL</div><div class="top-actions"><span class="pill">Lecturer account</span><button class="theme-btn" id="themeToggle" type="button" aria-label="Toggle light and dark mode">☾</button><form method="post" action="<?= e(url('auth/logout.php')) ?>" style="margin:0"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><button type="submit" class="logout" style="border:0;background:none;cursor:pointer">Log out ↗</button></form></div></header>
<section class="intro"><div class="eyebrow">Account management</div><h1>My Profile <span>&</span> Settings<span>.</span></h1><p>Manage your teaching profile, secure your account, and choose your preferred appearance.</p></section>
<div class="profile-head"><div class="avatar" aria-hidden="true"><?= e($initial) ?></div><div><strong><?= e((string)$profile['full_name']) ?></strong><small><?= e((string)$profile['email']) ?></small></div></div>
<?php if ($notice !== ''): ?><div class="message success" role="status"><?= e($notice) ?></div><?php endif; ?>
<?php if ($error !== ''): ?><div class="message error" role="alert"><?= e($error) ?></div><?php endif; ?>
<div class="cards">
<section class="card"><h2>Personal information</h2><p class="hint">Update how your name appears in ULearn.</p>
<form method="post"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="update_profile"><div class="field"><label for="full_name">Full name</label><input id="full_name" name="full_name" maxlength="120" required autocomplete="name" value="<?= e((string)$profile['full_name']) ?>"></div><div class="field"><label for="username">Username</label><input id="username" name="username" maxlength="40" required value="<?= e((string)($profile['username'] ?? '')) ?>"></div><div class="field"><label for="email">Email address</label><input id="email" type="email" readonly value="<?= e((string)$profile['email']) ?>"></div><button class="btn" type="submit">Save profile</button></form></section>
<section class="card"><h2>Professional details</h2><p class="hint">Your teaching profile is managed by an administrator.</p>
<div class="field"><label>Title</label><input readonly value="<?= e((string)($lecturer['title'] ?? '')) ?>"></div>
<div class="field"><label>Designation</label><input readonly value="<?= e((string)($lecturer['designation'] ?? '')) ?>"></div>
<div class="field"><label>Department</label><input readonly value="<?= e((string)($lecturer['department'] ?? '')) ?>"></div></section>
<section class="card"><h2>Change password</h2><p class="hint">Use at least 8 characters, one uppercase letter, one number and one symbol.</p>
<form method="post" autocomplete="on"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="change_password"><div class="field"><label for="current_password">Current password</label><input id="current_password" name="current_password" type="password" autocomplete="current-password" required></div><div class="field"><label for="new_password">New password</label><input id="new_password" name="new_password" type="password" autocomplete="new-password" minlength="8" maxlength="128" required></div><div class="field"><label for="confirm_password">Confirm new password</label><input id="confirm_password" name="confirm_password" type="password" autocomplete="new-password" minlength="8" maxlength="128" required></div><button class="btn" type="submit">Change password</button></form></section>
<section class="card wide"><h2>Appearance</h2><p class="hint">Choose how ULearn looks on this account.</p><form method="post"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="update_theme"><div class="field"><label for="theme">Theme preference</label><select id="theme" name="theme"><option value="light" <?= $theme === 'light' ? 'selected' : '' ?>>Light</option><option value="dark" <?= $theme === 'dark' ? 'selected' : '' ?>>Dark</option><option value="system" <?= $theme === 'system' ? 'selected' : '' ?>>Use device setting</option></select></div><button class="btn" type="submit">Save appearance</button><div class="subtle">The theme toggle in the header previews your preference instantly.</div></form></section>
</div>
</main>
</div>
<script>
(function () {
  var button = document.getElementById('themeToggle');
  function updateIcon() { button.textContent = document.documentElement.getAttribute('data-theme') === 'dark' ? '☀' : '☾'; }
  updateIcon();
  button.addEventListener('click', function () {
    var next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('ulearn-theme', next);
    updateIcon();
  });
  var selector = document.getElementById('theme');
  selector.form.addEventListener('submit', function () {
    var value = selector.value;
    localStorage.setItem('ulearn-theme', value);
  });
})();
</script>
</body>
</html>
