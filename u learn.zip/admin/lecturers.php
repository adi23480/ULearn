<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';

$admin = require_login();

if (!in_array($admin['role'], ['admin', 'main_admin'], true)) {
    http_response_code(403);
    exit('Access denied. Admin permission required.');
}

$pdo = db();
$error = '';
$success = '';

function lecturerRedirect(): never
{
    go('admin/lecturers.php');
}

if (isset($_SESSION['lecturer_success'])) {
    $success = (string)$_SESSION['lecturer_success'];
    unset($_SESSION['lecturer_success']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $action = (string)($_POST['action'] ?? '');

    try {
        if ($action === 'approve') {
            $email = strtolower(trim((string)($_POST['email'] ?? '')));
            $title = (string)($_POST['title'] ?? 'Mr.');
            $department = trim((string)($_POST['department'] ?? ''));
            $designation = trim((string)($_POST['designation'] ?? ''));

            $allowedTitles = ['Mr.', 'Mrs.', 'Ms.', 'Dr.', 'Prof.'];

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new RuntimeException('Enter a valid registered email.');
            }

            if (!in_array($title, $allowedTitles, true)) {
                throw new RuntimeException('Choose a valid title.');
            }

            if (strlen($department) > 150 || strlen($designation) > 150) {
                throw new RuntimeException(
                    'Department and designation must be under 150 characters.'
                );
            }

            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                "SELECT id, full_name, email, role, email_verified_at
                 FROM users
                 WHERE email = ?
                 LIMIT 1
                 FOR UPDATE"
            );

            $stmt->execute([$email]);
            $account = $stmt->fetch();

            if (!$account) {
                throw new RuntimeException(
                    'No registered account was found for this email. ' .
                    'Ask the lecturer to register and verify their email first.'
                );
            }

            if ($account['role'] !== 'student') {
                throw new RuntimeException(
                    'Only verified student-role accounts can be promoted. ' .
                    'Admin accounts cannot be changed here.'
                );
            }

            if (empty($account['email_verified_at'])) {
                throw new RuntimeException(
                    'The account must complete email verification first.'
                );
            }

            if ((int)$account['id'] === (int)$admin['id']) {
                throw new RuntimeException(
                    'You cannot change your own account role.'
                );
            }

            $stmt = $pdo->prepare(
                "UPDATE users
                 SET role = 'lecturer'
                 WHERE id = ? AND role = 'student'"
            );

            $stmt->execute([(int)$account['id']]);

            if ($stmt->rowCount() !== 1) {
                throw new RuntimeException('Could not grant lecturer access.');
            }

            $stmt = $pdo->prepare(
                "INSERT INTO lecturer_profiles
                    (user_id, title, department, designation, is_active)
                 VALUES (?, ?, ?, ?, 1)
                 ON DUPLICATE KEY UPDATE
                    title = VALUES(title),
                    department = VALUES(department),
                    designation = VALUES(designation),
                    is_active = 1"
            );

            $stmt->execute([
                (int)$account['id'],
                $title,
                $department !== '' ? $department : null,
                $designation !== '' ? $designation : null
            ]);

            $pdo->commit();

            $_SESSION['lecturer_success'] =
                'Lecturer access granted to ' . $account['full_name'] . '.';

            lecturerRedirect();
        }

        if ($action === 'toggle') {
            $lecturerId = filter_var(
                $_POST['lecturer_id'] ?? null,
                FILTER_VALIDATE_INT
            );

            if (!$lecturerId || $lecturerId < 1) {
                throw new RuntimeException('Invalid lecturer.');
            }

            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                "SELECT lp.id, lp.is_active, u.full_name, u.role
                 FROM lecturer_profiles lp
                 JOIN users u ON u.id = lp.user_id
                 WHERE lp.id = ?
                 LIMIT 1
                 FOR UPDATE"
            );

            $stmt->execute([$lecturerId]);
            $lecturer = $stmt->fetch();

            if (!$lecturer || $lecturer['role'] !== 'lecturer') {
                throw new RuntimeException('Lecturer not found.');
            }

            $newStatus = (int)$lecturer['is_active'] === 1 ? 0 : 1;

            $stmt = $pdo->prepare(
                "UPDATE lecturer_profiles
                 SET is_active = ?
                 WHERE id = ?"
            );

            $stmt->execute([$newStatus, $lecturerId]);

            $pdo->commit();

            $_SESSION['lecturer_success'] =
                $lecturer['full_name'] .
                ($newStatus ? ' activated.' : ' suspended.');

            lecturerRedirect();
        }

        throw new RuntimeException('Unknown action.');

    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        if ($exception instanceof RuntimeException) {
            $error = $exception->getMessage();
        } else {
            error_log('Lecturer management error: ' . $exception->getMessage());
            $error = 'Something went wrong. Please try again.';
        }
    }
}

$stmt = $pdo->query(
    "SELECT
        lp.id,
        lp.title,
        lp.department,
        lp.designation,
        lp.is_active,
        u.full_name,
        u.email,
        u.email_verified_at,
        (
            SELECT COUNT(*)
            FROM lecturer_module_assignments lma
            WHERE lma.lecturer_id = lp.id
              AND lma.is_active = 1
        ) AS module_count
     FROM lecturer_profiles lp
     JOIN users u ON u.id = lp.user_id
     WHERE u.role = 'lecturer'
     ORDER BY lp.is_active DESC, u.full_name ASC"
);

$lecturers = $stmt->fetchAll();
$activeCount = count(array_filter(
    $lecturers,
    fn($item) => (int)$item['is_active'] === 1
));

$theme = (string)($admin['theme'] ?? 'system');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manage Lecturers — U Learn</title>

    <script>
        const preferred = <?= json_encode($theme) ?>;
        const stored = localStorage.getItem('ulearn-theme');

        const initialTheme = ['light', 'dark'].includes(stored)
            ? stored
            : ['light', 'dark'].includes(preferred)
                ? preferred
                : window.matchMedia('(prefers-color-scheme: dark)').matches
                    ? 'dark' : 'light';

        document.documentElement.dataset.theme = initialTheme;

        function toggleTheme() {
            const next = document.documentElement.dataset.theme === 'dark'
                ? 'light' : 'dark';

            document.documentElement.dataset.theme = next;
            localStorage.setItem('ulearn-theme', next);
            updateThemeButton();
        }

        function updateThemeButton() {
            const button = document.getElementById('themeButton');

            if (button) {
                const dark = document.documentElement.dataset.theme === 'dark';
                button.textContent = dark ? '☀' : '☾';
                button.title = dark ? 'Light mode' : 'Dark mode';
                button.setAttribute(
                    'aria-label',
                    dark ? 'Switch to light mode' : 'Switch to dark mode'
                );
            }
        }

        document.addEventListener('DOMContentLoaded', updateThemeButton);
    </script>

    <style>
        :root {
            --bg: #f7f8fc;
            --card: #ffffff;
            --text: #191b2a;
            --muted: #777c90;
            --border: #e6e8f0;
            --accent: #6957e8;
            --soft: #f0edff;
            --input: #fafbff;
        }

        [data-theme="dark"] {
            --bg: #10121b;
            --card: #1b1e2b;
            --text: #f4f4fa;
            --muted: #a2a6b8;
            --border: #303344;
            --accent: #b0a2ff;
            --soft: #2c2745;
            --input: #232635;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            background: var(--bg);
            color: var(--text);
            font-family: Inter, -apple-system, BlinkMacSystemFont,
                "Segoe UI", Arial, sans-serif;
            line-height: 1.6;
        }

        .layout {
            max-width: 1120px;
            margin: auto;
            padding: 30px 24px 80px;
        }

        .topbar, .top-actions, .heading, .lecturer-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            flex-wrap: wrap;
        }

        .brand {
            font-size: 27px;
            font-weight: 800;
            letter-spacing: -1.5px;
            text-decoration: none;
            color: var(--text);
        }

        .brand span { color: var(--accent); }

        .top-actions a {
            color: var(--muted);
            text-decoration: none;
            font-size: 13px;
        }

        .theme-button {
            width: 40px;
            height: 40px;
            background: var(--card);
            color: var(--text);
            border: 1px solid var(--border);
            border-radius: 12px;
            font-size: 20px;
            cursor: pointer;
        }

        .intro { margin: 60px 0 30px; }

        .eyebrow {
            color: var(--muted);
            font-size: 11px;
            letter-spacing: 1.6px;
            font-weight: 800;
            text-transform: uppercase;
        }

        h1 {
            font-size: clamp(34px, 5vw, 54px);
            letter-spacing: -2px;
            line-height: 1.1;
            margin: 14px 0;
        }

        h1 span { color: var(--accent); }

        .subtitle { color: var(--muted); max-width: 650px; }

        .grid {
            display: grid;
            grid-template-columns: 360px minmax(0, 1fr);
            gap: 22px;
            align-items: start;
        }

        .card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 25px;
        }

        .card h2 {
            font-size: 20px;
            margin: 0 0 10px;
            letter-spacing: -.5px;
        }

        .hint {
            color: var(--muted);
            font-size: 13px;
            margin: 0 0 22px;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 700;
            margin: 16px 0 7px;
        }

        input, select {
            width: 100%;
            background: var(--input);
            color: var(--text);
            border: 1px solid var(--border);
            border-radius: 11px;
            padding: 12px 13px;
            font: inherit;
        }

        button { font: inherit; cursor: pointer; }

        .primary {
            width: 100%;
            margin-top: 22px;
            padding: 13px;
            border: 0;
            border-radius: 11px;
            background: var(--accent);
            color: white;
            font-size: 13px;
            font-weight: 750;
        }

        .count {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 100px;
            background: var(--soft);
            color: var(--accent);
            font-size: 12px;
            font-weight: 750;
        }

        .lecturer {
            padding: 20px 0;
            border-top: 1px solid var(--border);
        }

        .lecturer:first-of-type { border-top: none; }

        .lecturer-name {
            font-size: 16px;
            font-weight: 750;
        }

        .details {
            color: var(--muted);
            font-size: 13px;
            overflow-wrap: anywhere;
        }

        .status {
            display: inline-block;
            font-size: 11px;
            font-weight: 800;
            padding: 5px 10px;
            border-radius: 100px;
            background: var(--soft);
            color: var(--accent);
        }

        .status.off {
            background: var(--input);
            color: var(--muted);
        }

        .small-button {
            border: 1px solid var(--border);
            border-radius: 10px;
            background: var(--input);
            color: var(--text);
            padding: 8px 12px;
            margin-top: 12px;
            font-size: 12px;
            font-weight: 700;
        }

        .message {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 22px;
            font-size: 14px;
        }

        .success { background: #e5f7ee; color: #17663d; }
        .error { background: #ffe8eb; color: #a32143; }

        @media (max-width: 800px) {
            .grid { grid-template-columns: 1fr; }
            .intro { margin-top: 40px; }
        }
    </style>
</head>

<body>
<div class="layout">

    <header class="topbar">
        <a class="brand" href="<?= e(url()) ?>">
            u learn<span>.</span>
        </a>

        <div class="top-actions">
            <span class="eyebrow">
                <?= e(str_replace('_', ' ', $admin['role'])) ?>
            </span>

            <button
                id="themeButton"
                class="theme-button"
                type="button"
                onclick="toggleTheme()"
            >☾</button>
        </div>
    </header>

    <section class="intro">
        <div class="eyebrow">Administration / People</div>
        <h1>Manage lecturers<span>.</span></h1>
        <p class="subtitle">
            Grant lecturer access to verified accounts,
            manage teaching profiles and control access.
        </p>
    </section>

    <?php if ($success): ?>
        <div class="message success" role="status">
            <?= e($success) ?>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="message error" role="alert">
            <?= e($error) ?>
        </div>
    <?php endif; ?>

    <div class="grid">

        <section class="card">
            <h2>Approve a lecturer</h2>
            <p class="hint">
                The person must register and verify their email
                first. Only admins can grant lecturer access.
            </p>

            <form method="post">
                <input
                    type="hidden"
                    name="csrf"
                    value="<?= e(csrf()) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="approve"
                >

                <label for="email">Registered email</label>
                <input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="lecturer@university.edu"
                    maxlength="254"
                    required
                >

                <label for="title">Title</label>
                <select id="title" name="title">
                    <option value="Mr.">Mr.</option>
                    <option value="Mrs.">Mrs.</option>
                    <option value="Ms.">Ms.</option>
                    <option value="Dr.">Dr.</option>
                    <option value="Prof.">Prof.</option>
                </select>

                <label for="department">Department</label>
                <input
                    id="department"
                    name="department"
                    placeholder="e.g. Computing"
                    maxlength="150"
                >

                <label for="designation">Designation</label>
                <input
                    id="designation"
                    name="designation"
                    placeholder="e.g. Senior Lecturer"
                    maxlength="150"
                >

                <button class="primary" type="submit">
                    Grant Lecturer Access →
                </button>
            </form>
        </section>

        <section class="card">
            <div class="heading">
                <h2>Lecturer directory</h2>
                <span class="count">
                    <?= $activeCount ?> active
                </span>
            </div>

            <p class="hint">
                Approved lecturers and their account status.
            </p>

            <?php if (!$lecturers): ?>
                <p class="hint">
                    No lecturers approved yet.
                </p>
            <?php endif; ?>

            <?php foreach ($lecturers as $lecturer): ?>

                <article class="lecturer">
                    <div class="lecturer-head">
                        <div class="lecturer-name">
                            <?= e($lecturer['title']) ?>
                            <?= e($lecturer['full_name']) ?>
                        </div>

                        <span class="status <?= (int)$lecturer['is_active'] === 1 ? '' : 'off' ?>">
                            <?= (int)$lecturer['is_active'] === 1
                                ? 'Active'
                                : 'Suspended' ?>
                        </span>
                    </div>

                    <div class="details">
                        <?= e($lecturer['email']) ?><br>
                        <?= e($lecturer['department'] ?: 'No department') ?>
                        ·
                        <?= e($lecturer['designation'] ?: 'Lecturer') ?><br>
                        <?= (int)$lecturer['module_count'] ?>
                        teaching assignments
                    </div>

                    <form method="post">
                        <input
                            type="hidden"
                            name="csrf"
                            value="<?= e(csrf()) ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="toggle"
                        >

                        <input
                            type="hidden"
                            name="lecturer_id"
                            value="<?= (int)$lecturer['id'] ?>"
                        >

                        <button
                            class="small-button"
                            type="submit"
                            onclick="return confirm('Change lecturer access for this account?')"
                        >
                            <?= (int)$lecturer['is_active'] === 1
                                ? 'Suspend access'
                                : 'Reactivate access' ?>
                        </button>
                    </form>
                </article>

            <?php endforeach; ?>
        </section>

    </div>

</div>
</body>
</html>
