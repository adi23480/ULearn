ULearn Q&A discussion page redesign

Back up dashboard/group-peer/view.php before replacing it.
Copy dashboard/group-peer/view.php into C:\xampp\htdocs\ulearn\dashboard\group-peer\view.php
No SQL changes. Existing question/answer/voting/solve endpoints unchanged.
Test viewing, posting answers, question voting, accepting solutions, editing and deleting, and light/dark mode.
This patch targets the previously delivered ULearn_QA_Usability_Patch version.
