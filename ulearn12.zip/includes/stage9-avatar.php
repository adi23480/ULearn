<?php
// Requires $pdo, $userId, $profile, $notice, $error and csrf()/e().
$stage9Avatars = ['Nova Scout','Night Glider','Solar Fox','Circuit Queen','Cosmic Pup','Storm Sentinel','Shadow Jester','Nebula Witch','Crimson Phantom','Glitch Goblin','Moon Guardian','Titan Bloom'];
$stage9Default = (($userId * 17) % count($stage9Avatars)) + 1;
$stage9Avatar = $pdo->prepare('SELECT avatar_key FROM user_comic_avatars WHERE user_id=?');
$stage9Avatar->execute([$userId]);
$stage9Key = (int)($stage9Avatar->fetchColumn() ?: $stage9Default);
if ($stage9Key < 1 || $stage9Key > count($stage9Avatars)) $stage9Key=$stage9Default;
?>
<section class="stage9-card">
<div class="stage9-head"><img src="<?= e(url('assets/avatars/'.sprintf('%02d',$stage9Key).'.svg')) ?>" alt="My comic avatar"><div><h2>My comic identity</h2><p><?= e($stage9Avatars[$stage9Key-1]) ?> · Your future AI assistant can use this avatar.</p></div></div>
<form method="post" class="avatar-form"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="stage9_avatar"><div class="avatar-chooser" role="radiogroup" aria-label="Choose your comic character"><?php foreach($stage9Avatars as $i=>$label): ?><label class="avatar-pick"><input type="radio" name="avatar_key" value="<?= $i+1 ?>" <?= $stage9Key===$i+1?'checked':'' ?>><img loading="lazy" alt="" src="<?= e(url('assets/avatars/'.sprintf('%02d',$i+1).'.svg')) ?>"><span><?= e($label) ?></span></label><?php endforeach ?></div><button class="stage9-button" type="submit">Save my character</button></form><style>.avatar-chooser{display:grid;grid-template-columns:repeat(auto-fill,minmax(122px,1fr));gap:13px;margin:20px 0}.avatar-pick{position:relative;cursor:pointer;padding:10px;border:1.5px solid var(--border,#3b3e52);border-radius:17px;text-align:center;transition:transform .2s,border-color .2s,box-shadow .2s;background:var(--input,#161927)}.avatar-pick:hover{transform:translateY(-3px)}.avatar-pick:has(input:checked){border-color:var(--accent,#a99cff);box-shadow:0 0 0 3px #977df62b}.avatar-pick input{position:absolute;right:9px;top:9px;accent-color:#8d76ed}.avatar-pick img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:12px}.avatar-pick span{display:block;font-size:12px;font-weight:650;margin-top:8px;line-height:1.3}.stage9-head img{object-fit:cover}@media(max-width:560px){.avatar-chooser{grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.avatar-pick{padding:6px}.avatar-pick span{font-size:10px}}</style>
</section>
