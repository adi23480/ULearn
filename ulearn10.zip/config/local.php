

<?php

return [
    // XAMPP database settings
    'db_host' => 'localhost',
    'db_name' => 'ulearn',
    'db_user' => 'root',
    'db_password' => '',

    // AI API keys
    'gemini_api_key' => 'AQ.Ab8RN6ICdE2ES1yrj214gOiqP9OAi40ofcjD3F8f3qdkEW_Yyw',
    'openrouter_api_key' => 'sk-or-v1-6a1fd6126c353aad35fae952b5c02425ca8841PbWWqgKDBDorh525uecKaGZD21FGSoCeR',
];
