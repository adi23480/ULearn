<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';
$user = require_login();
if ((string)$user['role'] !== 'student') {
    http_response_code(403);
    exit('Student access only.');
}

$pdo = db();
$userId = (int)$user['id'];
$selectedModuleId = isset($_GET['module_id']) ? filter_var($_GET['module_id'], FILTER_VALIDATE_INT) : null;
if (!$selectedModuleId || $selectedModuleId < 1) $selectedModuleId = null;
$theme = (string)($user['theme'] ?? 'system');
$topics = [];
$recentMistakes = [];
$error = '';
$profile = null;

try {
    $stmt = $pdo->prepare("SELECT d.name AS degree_name, b.batch_code
        FROM student_academic_profiles p
        JOIN academic_degrees d ON d.id=p.degree_id
        JOIN academic_batches b ON b.id=p.batch_id
        WHERE p.user_id=? LIMIT 1");
    $stmt->execute([$userId]);
    $profile = $stmt->fetch() ?: null;

    // Only submitted attempts are included. Accuracy is based on answers actually recorded.
    $stmt = $pdo->prepare("SELECT
            COALESCE(NULLIF(TRIM(qq.topic), ''), 'General') AS topic,
            COUNT(*) AS questions_seen,
            SUM(CASE WHEN aa.option_id IS NOT NULL THEN 1 ELSE 0 END) AS answered_count,
            SUM(CASE WHEN aa.option_id IS NOT NULL AND aa.is_correct=1 THEN 1 ELSE 0 END) AS correct_count,
            SUM(CASE WHEN aa.option_id IS NOT NULL AND aa.is_correct=0 THEN 1 ELSE 0 END) AS incorrect_count,
            ROUND(100.0 * SUM(CASE WHEN aa.option_id IS NOT NULL AND aa.is_correct=1 THEN 1 ELSE 0 END)
                / NULLIF(SUM(CASE WHEN aa.option_id IS NOT NULL THEN 1 ELSE 0 END), 0), 1) AS accuracy
        FROM quiz_attempt_answers aa
        JOIN quiz_attempts a ON a.id=aa.attempt_id
        JOIN quiz_questions qq ON qq.id=aa.question_id
        JOIN quizzes q ON q.id=a.quiz_id
        WHERE a.user_id=? AND a.status IN ('submitted','timed_out') AND (? IS NULL OR q.module_id=?)
        GROUP BY COALESCE(NULLIF(TRIM(qq.topic), ''), 'General')
        HAVING SUM(CASE WHEN aa.option_id IS NOT NULL THEN 1 ELSE 0 END) > 0
        ORDER BY accuracy ASC, answered_count DESC, topic ASC");
    $stmt->execute([$userId, $selectedModuleId, $selectedModuleId]);
    $topics = $stmt->fetchAll();

    $stmt = $pdo->prepare("SELECT
            COALESCE(NULLIF(TRIM(qq.topic), ''), 'General') AS topic,
            qq.question_text,
            q.title AS quiz_title,
            aa.is_correct,
            aa.option_id,
            selected.option_text AS selected_text,
            correct.option_text AS correct_text,
            COALESCE(NULLIF(TRIM(qq.explanation), ''), '') AS explanation,
            COALESCE(a.submitted_at, a.started_at) AS attempted_at
        FROM quiz_attempt_answers aa
        JOIN quiz_attempts a ON a.id=aa.attempt_id
        JOIN quiz_questions qq ON qq.id=aa.question_id
        JOIN quizzes q ON q.id=a.quiz_id
        LEFT JOIN quiz_options selected ON selected.id=aa.option_id
        LEFT JOIN quiz_options correct ON correct.question_id=qq.id AND correct.is_correct=1
        WHERE a.user_id=? AND a.status IN ('submitted','timed_out') AND (? IS NULL OR q.module_id=?)
          AND aa.option_id IS NOT NULL AND aa.is_correct=0
        ORDER BY COALESCE(a.submitted_at, a.started_at) DESC, aa.id DESC
        LIMIT 8");
    $stmt->execute([$userId, $selectedModuleId, $selectedModuleId]);
    $recentMistakes = $stmt->fetchAll();
} catch (Throwable $e) {
    error_log('ULearn topic analysis error: ' . $e->getMessage());
    $error = 'Topic analysis could not load. Please confirm that quiz-attempt tables are installed and try again.';
}

$firstName = preg_split('/\s+/', trim((string)$user['full_name']))[0] ?? 'Student';
$weakest = $topics[0] ?? null;
$strongest = count($topics) > 0 ? $topics[count($topics)-1] : null;
$totalAnswered = array_sum(array_map(static fn(array $t): int => (int)$t['answered_count'], $topics));
$totalCorrect = array_sum(array_map(static fn(array $t): int => (int)$t['correct_count'], $topics));
$overallAccuracy = $totalAnswered > 0 ? ($totalCorrect / $totalAnswered) * 100 : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Topic Mastery — ULearn</title>
<script>
(function(){
 const saved=<?= json_encode($theme, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
 const selected=saved==='light'||saved==='dark'?saved:null;
 document.documentElement.dataset.theme=selected || (window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');
})();
</script>
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.topic-wrap{width:min(1180px,calc(100% - 48px));margin:0 auto;padding:30px 0 64px}
.topic-top{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:28px}
.topic-brand{font:800 21px 'Manrope',sans-serif;letter-spacing:-1px}.topic-brand span{color:var(--accent)}
.topic-link{display:inline-flex;align-items:center;justify-content:center;border:1px solid var(--line);border-radius:12px;padding:10px 15px;background:var(--surface);font-size:13px;font-weight:700}
.topic-hero,.topic-card,.topic-stat{background:var(--surface);border:1px solid var(--line);border-radius:22px}
.topic-hero{padding:30px;margin-bottom:18px}
.kicker{font-size:10px;letter-spacing:1.7px;font-weight:850;text-transform:uppercase;color:var(--accent)}
.topic-hero h1{font:800 clamp(29px,4vw,44px)/1.1 'Manrope',sans-serif;letter-spacing:-1.8px;margin:10px 0}
.topic-hero p,.muted{color:var(--muted);line-height:1.7}
.topic-tags{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px}
.topic-tag{display:inline-flex;padding:6px 10px;border-radius:999px;background:var(--soft);color:var(--accent);font-size:10px;font-weight:800}
.topic-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:18px 0}
.topic-stat{padding:20px;min-width:0}.stat-label{font-size:12px;color:var(--muted);font-weight:700}
.stat-value{font:800 28px/1.2 'Manrope',sans-serif;letter-spacing:-1px;margin:8px 0}.stat-foot{font-size:11px;color:var(--muted)}
.topic-columns{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,.9fr);gap:16px;margin-top:16px}
.topic-card{padding:22px;min-width:0}.topic-card h2{font:800 19px 'Manrope',sans-serif;letter-spacing:-.5px;margin:5px 0 6px}
.card-desc{font-size:12px;color:var(--muted);line-height:1.65;margin:0 0 18px}
.topic-bars{display:grid;gap:18px}.bar-top{display:flex;justify-content:space-between;gap:10px;font-size:12px;margin-bottom:8px}
.bar-track{height:9px;border-radius:99px;background:var(--soft);overflow:hidden}.bar-fill{height:100%;border-radius:99px;background:linear-gradient(90deg,var(--accent),#a59aff)}
.level{font-size:10px;font-weight:800;padding:5px 8px;border-radius:99px;background:var(--soft);color:var(--accent);white-space:nowrap}
.topic-row{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;padding:14px 0;border-bottom:1px solid var(--line)}
.topic-row:last-child{border-bottom:0}.topic-row h3{font-size:13px;margin:0 0 5px}.topic-row p{font-size:11px;color:var(--muted);margin:0;line-height:1.6}
.mistake{padding:15px 0;border-bottom:1px solid var(--line)}.mistake:last-child{border-bottom:0}
.mistake-head{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:8px}
.mistake-title{font-size:12px;font-weight:800}.mistake-question{font-size:13px;line-height:1.6;margin:8px 0}
.answer-line{font-size:11px;line-height:1.7;color:var(--muted)}.answer-line strong{color:var(--text)}
.correct-answer{color:#159766!important}
.empty{padding:22px;border:1px dashed var(--line);border-radius:14px;color:var(--muted);font-size:13px;line-height:1.7}
.notice{padding:14px 16px;border:1px solid #f1c9a8;background:#fff5eb;color:#854d0e;border-radius:13px;margin-bottom:16px;font-size:13px}
.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}
@media(max-width:900px){.topic-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.topic-columns{grid-template-columns:1fr}}
@media(max-width:560px){.topic-wrap{width:calc(100% - 28px);padding-top:18px}.topic-hero,.topic-card,.topic-stat{padding:18px}.topic-top{align-items:flex-start}.stat-value{font-size:24px}}
</style>
</head>
<body>
<main class="topic-wrap">
<header class="topic-top">
 <a class="topic-brand" href="<?= e(url('dashboard/index.php')) ?>">u learn<span>.</span></a>
 <div style="display:flex;gap:8px;flex-wrap:wrap">
  <a class="topic-link" href="<?= e(url('dashboard/analytics.php')) ?>">← Performance Analytics</a>
  <a class="topic-link" href="<?= e(url('dashboard/index.php')) ?>">Dashboard</a>
 </div>
</header>
<?php if ($error !== ''): ?><div class="notice"><?= e($error) ?></div><?php endif; ?>
<section class="topic-hero">
 <div class="kicker">Understand · Practise · Improve</div>
 <h1>Topic Mastery <span style="color:var(--accent)">&amp; Weakness Analysis</span></h1>
 <p>Hi <?= e($firstName) ?> — these insights are calculated from your submitted quiz answers. Use them to decide what to revise next; they are learning guidance, not a judgement.</p>
 <?php if ($profile): ?><div class="topic-tags"><span class="topic-tag"><?= e((string)$profile['degree_name']) ?></span><span class="topic-tag">Batch <?= e((string)$profile['batch_code']) ?></span></div><?php endif; ?>
</section>
<section class="topic-stats">
 <article class="topic-stat"><div class="stat-label">Overall answer accuracy</div><div class="stat-value"><?= $totalAnswered ? number_format($overallAccuracy,1).'%' : '—' ?></div><div class="stat-foot"><?= number_format($totalAnswered) ?> answered questions counted</div></article>
 <article class="topic-stat"><div class="stat-label">Topics with results</div><div class="stat-value"><?= number_format(count($topics)) ?></div><div class="stat-foot">Based on recorded topic labels</div></article>
 <article class="topic-stat"><div class="stat-label">Focus topic</div><div class="stat-value" style="font-size:21px"><?= $weakest ? e((string)$weakest['topic']) : '—' ?></div><div class="stat-foot"><?= $weakest ? number_format((float)$weakest['accuracy'],1).'% accuracy' : 'Complete a quiz to unlock insights' ?></div></article>
 <article class="topic-stat"><div class="stat-label">Recent incorrect answers</div><div class="stat-value"><?= number_format(count($recentMistakes)) ?></div><div class="stat-foot">Up to 8 recent answers shown below</div></article>
</section>
<section class="topic-columns">
 <article class="topic-card">
  <div class="kicker">Topic breakdown</div><h2>Your accuracy by topic</h2><p class="card-desc">Topics are ordered from lower to higher accuracy. A topic with only a few answers may change quickly as you practise.</p>
  <?php if (!$topics): ?><div class="empty"><strong>No topic data yet</strong>Complete and submit a quiz with recorded answers. Topics are taken from the topic field on each question; blank labels appear as General.</div>
  <?php else: ?><div class="topic-bars">
   <?php foreach ($topics as $topic): $acc=max(0,min(100,(float)$topic['accuracy'])); ?>
   <div><div class="bar-top"><strong><?= e((string)$topic['topic']) ?></strong><span><?= number_format($acc,1) ?>% · <?= (int)$topic['correct_count'] ?>/<?= (int)$topic['answered_count'] ?></span></div><div class="bar-track"><div class="bar-fill" style="width:<?= $acc ?>%"></div></div></div>
   <?php endforeach; ?>
  </div><?php endif; ?>
 </article>
 <article class="topic-card">
  <div class="kicker">Personal focus plan</div><h2>Where to focus next</h2><p class="card-desc">Suggested priorities are based on your recorded accuracy, not an AI-generated guess.</p>
  <?php if (!$topics): ?><div class="empty">Once you have quiz results, this panel will identify the topics with the lowest recorded accuracy.</div>
  <?php else: ?>
   <?php foreach (array_slice($topics,0,4) as $i=>$topic): ?>
    <div class="topic-row"><div><h3><?= e((string)$topic['topic']) ?></h3><p><?= (int)$topic['incorrect_count'] ?> incorrect out of <?= (int)$topic['answered_count'] ?> answered. <?= (int)$topic['answered_count'] < 5 ? 'Try a few more questions before drawing a firm conclusion.' : 'Review the concepts and retry related questions.' ?></p></div><span class="level"><?= (int)$topic['answered_count'] < 5 ? 'BUILD DATA' : ((float)$topic['accuracy'] < 60 ? 'HIGH PRIORITY' : 'PRACTISE') ?></span></div>
   <?php endforeach; ?>
  <?php endif; ?>
 </article>
</section>
<section class="topic-card" style="margin-top:16px">
 <div class="kicker">Review and learn</div><h2>Recent mistakes</h2><p class="card-desc">Use these records to revisit concepts you missed. Correct answers and explanations are shown here because these are submitted attempts.</p>
 <?php if (!$recentMistakes): ?><div class="empty"><strong>No incorrect answers to review yet</strong>When submitted quiz attempts contain incorrect answers, they will appear here.</div>
 <?php else: foreach ($recentMistakes as $mistake): ?>
 <article class="mistake">
  <div class="mistake-head"><span class="topic-tag"><?= e((string)$mistake['topic']) ?></span><span class="muted" style="font-size:11px"><?= e(date('d M Y', strtotime((string)$mistake['attempted_at']))) ?> · <?= e((string)$mistake['quiz_title']) ?></span></div>
  <div class="mistake-question"><?= e((string)$mistake['question_text']) ?></div>
  <div class="answer-line"><strong>Your answer:</strong> <?= e((string)($mistake['selected_text'] ?? 'No answer recorded')) ?></div>
  <div class="answer-line correct-answer"><strong>Correct answer:</strong> <?= e((string)($mistake['correct_text'] ?? 'Not available')) ?></div>
  <?php if (trim((string)$mistake['explanation']) !== ''): ?><div class="answer-line" style="margin-top:5px"><strong>Explanation:</strong> <?= e((string)$mistake['explanation']) ?></div><?php endif; ?>
 </article>
 <?php endforeach; endif; ?>
 <div class="actions"><a class="topic-link" href="<?= e(url('dashboard/quizzes.php')) ?>">Practise a quiz →</a><a class="topic-link" href="<?= e(url('dashboard/analytics.php')) ?>">Back to analytics</a></div>
</section>
</main>
</body>
</html>
