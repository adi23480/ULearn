<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';
$user = require_login();
if ((string)$user['role'] !== 'student') {
    http_response_code(403);
    exit('Student access only.');
}

$pdo = db();
$userId = (int)$user['id'];
$selectedModuleId = isset($_GET['module_id']) ? filter_var($_GET['module_id'], FILTER_VALIDATE_INT) : null;
if (!$selectedModuleId || $selectedModuleId < 1) $selectedModuleId = null;
$theme = (string)($user['theme'] ?? 'system');
$error = '';
$profile = null;
$attempts = [];
$moduleStats = [];
$topicStats = [];
$completedCount = 0;
$averagePercent = 0.0;
$bestPercent = 0.0;
$answeredCount = 0;
$correctCount = 0;
$completionRate = 0.0;

try {
    $stmt = $pdo->prepare("SELECT d.name AS degree_name, b.batch_code
        FROM student_academic_profiles p
        JOIN academic_degrees d ON d.id=p.degree_id
        JOIN academic_batches b ON b.id=p.batch_id
        WHERE p.user_id=? LIMIT 1");
    $stmt->execute([$userId]);
    $profile = $stmt->fetch() ?: null;

    $stmt = $pdo->prepare("SELECT a.id, a.score, a.max_score, a.status, a.submitted_at,
            q.title, m.module_code, m.module_name,
            CASE WHEN a.max_score > 0 THEN (a.score / a.max_score) * 100 ELSE 0 END AS percent_score
        FROM quiz_attempts a
        JOIN quizzes q ON q.id=a.quiz_id
        JOIN academic_modules m ON m.id=q.module_id
        WHERE a.user_id=? AND a.status <> 'in_progress' AND (? IS NULL OR q.module_id=?)
        ORDER BY COALESCE(a.submitted_at, a.started_at) DESC, a.id DESC");
    $stmt->execute([$userId, $selectedModuleId, $selectedModuleId]);
    $attempts = $stmt->fetchAll();

    $completedCount = count($attempts);
    if ($completedCount > 0) {
        $percentages = array_map(static fn(array $a): float => (float)$a['percent_score'], $attempts);
        $averagePercent = array_sum($percentages) / count($percentages);
        $bestPercent = max($percentages);
    }

    $stmt = $pdo->prepare("SELECT m.module_code, m.module_name,
            COUNT(a.id) AS attempt_count,
            AVG(CASE WHEN a.max_score > 0 THEN (a.score / a.max_score) * 100 ELSE 0 END) AS average_percent,
            MAX(CASE WHEN a.max_score > 0 THEN (a.score / a.max_score) * 100 ELSE 0 END) AS best_percent
        FROM quiz_attempts a
        JOIN quizzes q ON q.id=a.quiz_id
        JOIN academic_modules m ON m.id=q.module_id
        WHERE a.user_id=? AND a.status <> 'in_progress' AND (? IS NULL OR q.module_id=?)
        GROUP BY m.id, m.module_code, m.module_name
        ORDER BY average_percent ASC, m.module_code ASC");
    $stmt->execute([$userId, $selectedModuleId, $selectedModuleId]);
    $moduleStats = $stmt->fetchAll();

    $stmt = $pdo->prepare("SELECT COALESCE(NULLIF(TRIM(qq.topic), ''), 'General') AS topic,
            COUNT(CASE WHEN aa.option_id IS NOT NULL THEN 1 END) AS answered_count,
            SUM(CASE WHEN aa.option_id IS NOT NULL AND aa.is_correct=1 THEN 1 ELSE 0 END) AS correct_count,
            AVG(CASE WHEN aa.option_id IS NOT NULL THEN CASE WHEN aa.is_correct=1 THEN 100 ELSE 0 END ELSE NULL END) AS accuracy
        FROM quiz_attempt_answers aa
        JOIN quiz_attempts a ON a.id=aa.attempt_id
        JOIN quiz_questions qq ON qq.id=aa.question_id
        JOIN quizzes q ON q.id=a.quiz_id
        WHERE a.user_id=? AND a.status <> 'in_progress' AND (? IS NULL OR q.module_id=?)
        GROUP BY COALESCE(NULLIF(TRIM(qq.topic), ''), 'General')
        HAVING COUNT(CASE WHEN aa.option_id IS NOT NULL THEN 1 END) > 0
        ORDER BY accuracy ASC, answered_count DESC
        LIMIT 6");
    $stmt->execute([$userId, $selectedModuleId, $selectedModuleId]);
    $topicStats = $stmt->fetchAll();

    $stmt = $pdo->prepare("SELECT COUNT(CASE WHEN aa.option_id IS NOT NULL THEN 1 END) AS answered_count,
            SUM(CASE WHEN aa.option_id IS NOT NULL AND aa.is_correct=1 THEN 1 ELSE 0 END) AS correct_count
        FROM quiz_attempt_answers aa
        JOIN quiz_attempts a ON a.id=aa.attempt_id
        JOIN quizzes q ON q.id=a.quiz_id
        WHERE a.user_id=? AND a.status <> 'in_progress' AND (? IS NULL OR q.module_id=?)");
    $stmt->execute([$userId, $selectedModuleId, $selectedModuleId]);
    $answerTotals = $stmt->fetch() ?: [];
    $answeredCount = (int)($answerTotals['answered_count'] ?? 0);
    $correctCount = (int)($answerTotals['correct_count'] ?? 0);
    $completionRate = $answeredCount > 0 ? ($correctCount / $answeredCount) * 100 : 0.0;
} catch (Throwable $e) {
    error_log('ULearn analytics error: ' . $e->getMessage());
    $error = 'Analytics could not be loaded. Please confirm that the quiz-attempt database tables are installed, then refresh this page.';
}

$firstName = preg_split('/\s+/', trim((string)$user['full_name']))[0] ?? 'Student';
$recent = array_slice($attempts, 0, 6);
$trend = array_slice(array_reverse($attempts), -8);
$trendPoints = [];
foreach ($trend as $i => $a) {
    $trendPoints[] = ['x' => $i, 'y' => max(0, min(100, (float)$a['percent_score'])), 'label' => (string)$a['module_code']];
}
$chartW = 640; $chartH = 190; $left = 28; $right = 16; $top = 14; $bottom = 28;
$plotW = $chartW - $left - $right; $plotH = $chartH - $top - $bottom;
$pointCoords = [];
if (count($trendPoints) === 1) {
    $pointCoords[] = ['x' => $left + $plotW / 2, 'y' => $top + (100 - $trendPoints[0]['y']) / 100 * $plotH, 'value' => $trendPoints[0]['y'], 'label' => $trendPoints[0]['label']];
} else {
    foreach ($trendPoints as $p) {
        $x = $left + ($p['x'] / max(1, count($trendPoints)-1)) * $plotW;
        $y = $top + (100 - $p['y']) / 100 * $plotH;
        $pointCoords[] = ['x'=>$x, 'y'=>$y, 'value'=>$p['y'], 'label'=>$p['label']];
    }
}
$linePath = '';
foreach ($pointCoords as $i => $p) $linePath .= ($i === 0 ? 'M ' : ' L ') . round($p['x'], 2) . ' ' . round($p['y'], 2);
$areaPath = $linePath;
if ($pointCoords) $areaPath .= ' L ' . round($pointCoords[count($pointCoords)-1]['x'],2) . ' ' . ($top+$plotH) . ' L ' . round($pointCoords[0]['x'],2) . ' ' . ($top+$plotH) . ' Z';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Performance Analytics — ULearn</title>
<script>
(function(){
 const saved=<?= json_encode($theme, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
 const selected=saved==='light'||saved==='dark'?saved:null;
 const theme=selected || (window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');
 document.documentElement.dataset.theme=theme;
})();
</script>
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.analytics-wrap{width:min(1180px,calc(100% - 48px));margin:0 auto;padding:30px 0 64px}.analytics-top{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:28px}.analytics-brand{font:800 21px 'Manrope',sans-serif;letter-spacing:-1px}.analytics-brand span{color:var(--accent)}.back-link,.analytics-btn{display:inline-flex;align-items:center;justify-content:center;border:1px solid var(--line);border-radius:12px;padding:10px 15px;background:var(--surface);font-size:13px;font-weight:700}.analytics-hero{padding:30px;border:1px solid var(--line);border-radius:24px;background:var(--surface);margin-bottom:20px}.analytics-kicker{font-size:10px;letter-spacing:1.7px;font-weight:850;text-transform:uppercase;color:var(--accent)}.analytics-hero h1{font:800 clamp(30px,4vw,46px)/1.1 'Manrope',sans-serif;letter-spacing:-2px;margin:10px 0}.analytics-hero p{color:var(--muted);margin:0;line-height:1.7}.analytics-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:18px 0}.analytics-stat,.analytics-card{background:var(--surface);border:1px solid var(--line);border-radius:20px;padding:22px;min-width:0}.analytics-stat .stat-icon{width:36px;height:36px;display:grid;place-items:center;border-radius:12px;background:var(--soft);color:var(--accent);font-size:17px;margin-bottom:15px}.analytics-stat .stat-label{font-size:12px;color:var(--muted);font-weight:700}.analytics-stat .stat-value{font:800 30px/1.2 'Manrope',sans-serif;letter-spacing:-1.2px;margin:7px 0}.analytics-stat .stat-foot{font-size:11px;color:var(--muted)}.analytics-columns{display:grid;grid-template-columns:minmax(0,1.25fr) minmax(300px,.75fr);gap:16px;margin-top:16px}.analytics-card h2{font:800 19px 'Manrope',sans-serif;letter-spacing:-.6px;margin:5px 0 6px}.card-description{font-size:12px;color:var(--muted);margin:0 0 18px;line-height:1.65}.analytics-card-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:14px}.analytics-tag{display:inline-flex;padding:6px 9px;border-radius:999px;background:var(--soft);color:var(--accent);font-size:10px;font-weight:800;white-space:nowrap}.chart{width:100%;height:auto;display:block;overflow:visible}.chart text{fill:var(--muted);font:11px 'DM Sans',sans-serif}.chart-grid{stroke:var(--line);stroke-dasharray:4 5}.chart-area{fill:var(--soft);opacity:.9}.chart-line{fill:none;stroke:var(--accent);stroke-width:3;stroke-linecap:round;stroke-linejoin:round}.chart-dot{fill:var(--surface);stroke:var(--accent);stroke-width:3}.bar-list{display:grid;gap:18px}.bar-item-top{display:flex;justify-content:space-between;gap:10px;font-size:12px;margin-bottom:8px}.bar-item-top strong{font-weight:800}.bar-track{height:8px;background:var(--soft);border-radius:999px;overflow:hidden}.bar-fill{height:100%;border-radius:999px;background:linear-gradient(90deg,var(--accent),#a59aff)}.module-list{display:grid;gap:10px}.module-row{display:flex;justify-content:space-between;align-items:center;gap:14px;padding:13px;border:1px solid var(--line);border-radius:13px}.module-row strong{display:block;font-size:12px}.module-row small{display:block;color:var(--muted);font-size:11px;margin-top:3px}.module-score{text-align:right;font-weight:850;font-size:15px;white-space:nowrap}.module-score small{font-weight:600}.result-list{display:grid;gap:0}.result-row{display:flex;align-items:center;justify-content:space-between;gap:15px;padding:14px 0;border-bottom:1px solid var(--line)}.result-row:last-child{border-bottom:0}.result-title{font-size:12px;font-weight:800}.result-meta{font-size:11px;color:var(--muted);margin-top:4px}.result-right{text-align:right;white-space:nowrap}.result-right strong{font-size:14px}.result-right small{display:block;font-size:10px;color:var(--muted)}.empty-state{padding:24px;border:1px dashed var(--line);border-radius:14px;color:var(--muted);font-size:13px;line-height:1.7}.empty-state strong{display:block;color:var(--text);font-size:14px;margin-bottom:4px}.analytics-message{padding:14px 16px;border:1px solid #f1c9a8;background:#fff5eb;color:#854d0e;border-radius:13px;margin-bottom:16px;font-size:13px}.analytics-footer{color:var(--muted);font-size:11px;text-align:center;margin-top:25px}.analytics-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}.analytics-btn.primary{background:var(--accent);border-color:var(--accent);color:#fff}.weak-note{padding:13px 14px;border-radius:13px;background:var(--soft);color:var(--muted);font-size:12px;line-height:1.7;margin-top:18px}.weak-note strong{color:var(--text)}
@media(max-width:900px){.analytics-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.analytics-columns{grid-template-columns:1fr}}@media(max-width:560px){.analytics-wrap{width:calc(100% - 28px);padding-top:18px}.analytics-top{align-items:flex-start}.analytics-hero,.analytics-card,.analytics-stat{padding:18px}.analytics-grid{gap:10px}.analytics-stat .stat-value{font-size:25px}.back-link{font-size:11px;padding:9px 10px}}
</style>
</head>
<body>
<main class="analytics-wrap">
 <header class="analytics-top"><a class="analytics-brand" href="<?= e(url('dashboard/index.php')) ?>">u learn<span>.</span></a><a class="back-link" href="<?= e(url('dashboard/topic-analysis.php')) ?>">Topic Mastery →</a>
 <a class="back-link" href="<?= e(url('dashboard/index.php')) ?>">← Back to dashboard</a></header>
 <?php if ($error !== ''): ?><div class="analytics-message"><?= e($error) ?></div><?php endif; ?>
 <section class="analytics-hero"><div class="analytics-kicker">Your learning · Measured</div><h1><?= $selectedModuleId ? 'Module' : 'Performance' ?> <span style="color:var(--accent)"><?= $selectedModuleId ? 'Analytics' : 'Analytics' ?></span></h1><p>Hi <?= e($firstName) ?> — review your quiz progress, spot topics that need practice, and see how your results change over time.</p>
 <?php if ($profile): ?><div class="analytics-actions"><span class="analytics-tag"><?= e((string)$profile['degree_name']) ?></span><span class="analytics-tag">Batch <?= e((string)$profile['batch_code']) ?></span></div><?php endif; ?></section>
 <section class="analytics-grid" aria-label="Performance summary">
  <article class="analytics-stat"><div class="stat-icon">✓</div><div class="stat-label">Quizzes completed</div><div class="stat-value"><?= $completedCount ?></div><div class="stat-foot">Submitted attempts</div></article>
  <article class="analytics-stat"><div class="stat-icon">↗</div><div class="stat-label">Average score</div><div class="stat-value"><?= $completedCount ? number_format($averagePercent, 0) . '%' : '—' ?></div><div class="stat-foot">Across completed quizzes</div></article>
  <article class="analytics-stat"><div class="stat-icon">★</div><div class="stat-label">Personal best</div><div class="stat-value"><?= $completedCount ? number_format($bestPercent, 0) . '%' : '—' ?></div><div class="stat-foot">Your highest quiz percentage</div></article>
  <article class="analytics-stat"><div class="stat-icon">◎</div><div class="stat-label">Answer accuracy</div><div class="stat-value"><?= $answeredCount ? number_format($completionRate, 0) . '%' : '—' ?></div><div class="stat-foot"><?= $answeredCount ?> recorded answers</div></article>
 </section>
 <section class="analytics-columns">
  <article class="analytics-card"><div class="analytics-card-head"><div><div class="analytics-kicker">Score history</div><h2>Your progress</h2><p class="card-description">Your last <?= count($trend) ?> submitted attempts, in chronological order.</p></div><span class="analytics-tag">Score trend</span></div>
  <?php if (!$pointCoords): ?><div class="empty-state"><strong>Your chart will appear here</strong>Complete and submit a quiz to start building your personal progress history.</div><?php else: ?>
   <svg class="chart" viewBox="0 0 <?= $chartW ?> <?= $chartH ?>" role="img" aria-label="Quiz score trend chart">
    <?php foreach ([0,25,50,75,100] as $tick): $yy=$top+(100-$tick)/100*$plotH; ?><line class="chart-grid" x1="<?= $left ?>" y1="<?= round($yy,2) ?>" x2="<?= $chartW-$right ?>" y2="<?= round($yy,2) ?>"/><text x="<?= $left-8 ?>" y="<?= round($yy+4,2) ?>" text-anchor="end"><?= $tick ?>%</text><?php endforeach; ?>
    <?php if (count($pointCoords)>1): ?><path class="chart-area" d="<?= e($areaPath) ?>"/><path class="chart-line" d="<?= e($linePath) ?>"/><?php endif; ?>
    <?php foreach ($pointCoords as $i=>$p): ?><circle class="chart-dot" cx="<?= round($p['x'],2) ?>" cy="<?= round($p['y'],2) ?>" r="4"><title><?= e($p['label']) ?>: <?= number_format($p['value'],1) ?>%</title></circle><?php endforeach; ?>
    <text x="<?= $left ?>" y="<?= $chartH-5 ?>">Older</text><text x="<?= $chartW-$right ?>" y="<?= $chartH-5 ?>" text-anchor="end">Most recent</text>
   </svg>
  <?php endif; ?></article>
  <article class="analytics-card"><div class="analytics-kicker">Focus next</div><h2>Topics to practise</h2><p class="card-description">Topics are ranked by recorded answer accuracy, lowest first.</p>
  <?php if (!$topicStats): ?><div class="empty-state"><strong>Topic insights are waiting</strong>Once you submit quizzes with topic labels, your strongest and weakest areas will appear here.</div><?php else: ?><div class="bar-list"><?php foreach ($topicStats as $topic): $accuracy=max(0,min(100,(float)$topic['accuracy'])); ?><div><div class="bar-item-top"><strong><?= e((string)$topic['topic']) ?></strong><span><?= number_format($accuracy,0) ?>%</span></div><div class="bar-track"><div class="bar-fill" style="width:<?= number_format($accuracy,2,'.','') ?>%"></div></div><div class="result-meta"><?= (int)$topic['correct_count'] ?> correct out of <?= (int)$topic['answered_count'] ?> answers</div></div><?php endforeach; ?></div><div class="weak-note"><strong>Study tip:</strong> Start with the first topic in this list. Review its explanations in Quiz Arena, then try another quiz to measure improvement.</div><?php endif; ?></article>
 </section>
 <section class="analytics-columns">
  <article class="analytics-card"><div class="analytics-kicker">Module breakdown</div><h2>Performance by module</h2><p class="card-description">Average score and number of submitted attempts for each module.</p>
  <?php if (!$moduleStats): ?><div class="empty-state"><strong>No module results yet</strong>Your module performance will be calculated after your first submitted quiz.</div><?php else: ?><div class="module-list"><?php foreach ($moduleStats as $m): ?><div class="module-row"><div><strong><?= e((string)$m['module_code']) ?> · <?= e((string)$m['module_name']) ?></strong><small><?= (int)$m['attempt_count'] ?> submitted attempt<?= (int)$m['attempt_count']===1?'':'s' ?></small></div><div class="module-score"><?= number_format((float)$m['average_percent'],0) ?>%<small> average</small></div></div><?php endforeach; ?></div><?php endif; ?></article>
  <article class="analytics-card"><div class="analytics-kicker">Recent activity</div><h2>Latest quiz results</h2><p class="card-description">Open any result to review your answers and explanations.</p>
  <?php if (!$recent): ?><div class="empty-state"><strong>No submitted quizzes yet</strong>Start a quiz to record your first result and unlock your analytics.</div><?php else: ?><div class="result-list"><?php foreach ($recent as $a): ?><div class="result-row"><div><div class="result-title"><?= e((string)$a['title']) ?></div><div class="result-meta"><?= e((string)$a['module_code']) ?> · <?= !empty($a['submitted_at']) ? e(date('d M Y',strtotime((string)$a['submitted_at']))) : 'Submitted' ?></div></div><div class="result-right"><strong><?= number_format((float)$a['percent_score'],0) ?>%</strong><small><?= e(rtrim(rtrim(number_format((float)$a['score'],2,'.',''),'0'),'.')) ?> / <?= e(rtrim(rtrim(number_format((float)$a['max_score'],2,'.',''),'0'),'.')) ?> marks</small><a class="result-meta" href="<?= e(url('dashboard/quizzes.php?result='.(int)$a['id'])) ?>">Review answers ↗</a></div></div><?php endforeach; ?></div><?php endif; ?>
  <div class="analytics-actions"><a class="analytics-btn primary" href="<?= e(url('dashboard/quizzes.php')) ?>">Go to Quiz Arena ↗</a></div></article>
 </section>
 <p class="analytics-footer">ULearn · Your analytics are based on your own submitted quiz attempts.</p>
</main>
</body></html>
